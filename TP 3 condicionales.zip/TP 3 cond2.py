nombre=input("ingrese nombre")
op=int(input("ingrese opcion"))
primerc=nombre[0].upper()

if op==1:
    print(nombre.upper())
elif op==2:
    print(nombre.lower())
elif op==3:
    print(nombre.title())