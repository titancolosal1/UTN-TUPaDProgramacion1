edad=int(input("ingrese edad"))

if edad>=18:
    print ("es mayor")
else:
    print ("es menor")
