mag=int(input("ingrese magnitud"))

if mag<3:
    print ("muy leve")
elif mag>=3 and mag<4:
    print ("leve")
elif mag>=4 and mag<5:
    print ("moderado")
elif mag>=5 and mag<6:
    print ("fuerte")
elif mag>=6 and mag<7:
    print ("muy fuerte")
elif mag>=7:
    print ("extremo")