edad=int(input("ingrese edad"))

if edad<12:
    print ("niño")
elif edad>12 and edad<18:
    print ("adolescente")
elif edad>18 and edad<30:
    print ("adulto joven")
elif edad>=30:
    print ("adulto mayor")
else:
    print ("invalido")