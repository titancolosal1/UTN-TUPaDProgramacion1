n=int(input("ingrese un numero"))

if n%2==0:
    print ("es par")
else:
    print ("es impar")