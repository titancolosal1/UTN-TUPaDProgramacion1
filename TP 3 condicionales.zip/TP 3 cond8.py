nota=int(input("ingrese nota"))

if nota>=6:
    print ("aprobado")
else:
    print ("desaprobado")