cadena=input("ingresar cadena")
ultima=cadena[-1].lower()

if ultima=="a" or ultima=="e" or ultima=="i" or ultima=="o" or ultima=="u":
    print(f"{ultima}!")
else:
    print(ultima)
