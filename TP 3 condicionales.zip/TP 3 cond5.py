passw=input("ingrese contraseña")

if len(passw)>=8 and len(passw)<=14:
    print ("correcto")
else:
    print ("incorrecto")
